--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.u_students DROP CONSTRAINT IF EXISTS u_students_village_id_fkey;
ALTER TABLE IF EXISTS ONLY public.u_students DROP CONSTRAINT IF EXISTS u_students_province_id_fkey;
ALTER TABLE IF EXISTS ONLY public.u_students DROP CONSTRAINT IF EXISTS u_students_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.u_students DROP CONSTRAINT IF EXISTS u_students_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.u_student_families DROP CONSTRAINT IF EXISTS u_student_families_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.u_parents DROP CONSTRAINT IF EXISTS u_parents_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_target DROP CONSTRAINT IF EXISTS t_target_periode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_target DROP CONSTRAINT IF EXISTS t_target_juz_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_target DROP CONSTRAINT IF EXISTS t_target_grade_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_juz_detail DROP CONSTRAINT IF EXISTS t_juz_detail_surah_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_juz_detail DROP CONSTRAINT IF EXISTS t_juz_detail_juz_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_halaqoh DROP CONSTRAINT IF EXISTS t_halaqoh_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_halaqoh_students DROP CONSTRAINT IF EXISTS t_halaqoh_students_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_halaqoh_students DROP CONSTRAINT IF EXISTS t_halaqoh_students_halaqoh_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_halaqoh DROP CONSTRAINT IF EXISTS t_halaqoh_periode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_exam DROP CONSTRAINT IF EXISTS t_exam_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_exam DROP CONSTRAINT IF EXISTS t_exam_periode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_exam DROP CONSTRAINT IF EXISTS t_exam_examiner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_daily_record DROP CONSTRAINT IF EXISTS t_daily_record_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_daily_record DROP CONSTRAINT IF EXISTS t_daily_record_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_daily_record DROP CONSTRAINT IF EXISTS t_daily_record_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_daily_record DROP CONSTRAINT IF EXISTS t_daily_record_start_surah_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_daily_record DROP CONSTRAINT IF EXISTS t_daily_record_halaqoh_id_fkey;
ALTER TABLE IF EXISTS ONLY public.t_daily_record DROP CONSTRAINT IF EXISTS t_daily_record_end_surah_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_weighting DROP CONSTRAINT IF EXISTS l_score_weighting_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_weighting DROP CONSTRAINT IF EXISTS l_score_weighting_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_summative DROP CONSTRAINT IF EXISTS l_score_summative_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_summative DROP CONSTRAINT IF EXISTS l_score_summative_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_summative DROP CONSTRAINT IF EXISTS l_score_summative_periode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_formative DROP CONSTRAINT IF EXISTS l_score_formative_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_formative DROP CONSTRAINT IF EXISTS l_score_formative_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_formative DROP CONSTRAINT IF EXISTS l_score_formative_chapter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_final DROP CONSTRAINT IF EXISTS l_score_final_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_final DROP CONSTRAINT IF EXISTS l_score_final_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_final DROP CONSTRAINT IF EXISTS l_score_final_periode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_attitude DROP CONSTRAINT IF EXISTS l_score_attitude_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_attitude DROP CONSTRAINT IF EXISTS l_score_attitude_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_score_attitude DROP CONSTRAINT IF EXISTS l_score_attitude_periode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_content DROP CONSTRAINT IF EXISTS l_content_chapter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_chapter DROP CONSTRAINT IF EXISTS l_chapter_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_attendance DROP CONSTRAINT IF EXISTS l_attendance_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_attendance DROP CONSTRAINT IF EXISTS l_attendance_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_attendance DROP CONSTRAINT IF EXISTS l_attendance_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.l_attendance DROP CONSTRAINT IF EXISTS l_attendance_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.db_village DROP CONSTRAINT IF EXISTS db_village_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.db_district DROP CONSTRAINT IF EXISTS db_district_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.db_city DROP CONSTRAINT IF EXISTS db_city_province_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_student_session DROP CONSTRAINT IF EXISTS c_student_session_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_student_session DROP CONSTRAINT IF EXISTS c_student_session_exam_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_question_options DROP CONSTRAINT IF EXISTS c_question_options_question_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_question DROP CONSTRAINT IF EXISTS c_question_bank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_exam_class DROP CONSTRAINT IF EXISTS c_exam_class_exam_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_exam_class DROP CONSTRAINT IF EXISTS c_exam_class_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_exam DROP CONSTRAINT IF EXISTS c_exam_bank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_bank DROP CONSTRAINT IF EXISTS c_bank_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_bank DROP CONSTRAINT IF EXISTS c_bank_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_answer DROP CONSTRAINT IF EXISTS c_answer_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_answer DROP CONSTRAINT IF EXISTS c_answer_selected_option_id_fkey;
ALTER TABLE IF EXISTS ONLY public.c_answer DROP CONSTRAINT IF EXISTS c_answer_question_id_fkey;
ALTER TABLE IF EXISTS ONLY public.at_subject DROP CONSTRAINT IF EXISTS at_subject_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.at_subject DROP CONSTRAINT IF EXISTS at_subject_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.at_subject DROP CONSTRAINT IF EXISTS at_subject_class_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_subject DROP CONSTRAINT IF EXISTS a_subject_homebase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_subject DROP CONSTRAINT IF EXISTS a_subject_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_subject_category DROP CONSTRAINT IF EXISTS a_subject_category_homebase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_periode DROP CONSTRAINT IF EXISTS a_periode_homebase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_major DROP CONSTRAINT IF EXISTS a_major_homebase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_grade DROP CONSTRAINT IF EXISTS a_grade_homebase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_class DROP CONSTRAINT IF EXISTS a_class_major_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_class DROP CONSTRAINT IF EXISTS a_class_homeroom_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_class DROP CONSTRAINT IF EXISTS a_class_homebase_id_fkey;
ALTER TABLE IF EXISTS ONLY public.a_class DROP CONSTRAINT IF EXISTS a_class_grade_id_fkey;
ALTER TABLE IF EXISTS ONLY public.u_users DROP CONSTRAINT IF EXISTS u_users_username_key;
ALTER TABLE IF EXISTS ONLY public.u_users DROP CONSTRAINT IF EXISTS u_users_pkey;
ALTER TABLE IF EXISTS ONLY public.u_teachers DROP CONSTRAINT IF EXISTS u_teachers_pkey;
ALTER TABLE IF EXISTS ONLY public.u_students DROP CONSTRAINT IF EXISTS u_students_pkey;
ALTER TABLE IF EXISTS ONLY public.u_student_families DROP CONSTRAINT IF EXISTS u_student_families_pkey;
ALTER TABLE IF EXISTS ONLY public.u_parents DROP CONSTRAINT IF EXISTS u_parents_pkey;
ALTER TABLE IF EXISTS ONLY public.u_admin DROP CONSTRAINT IF EXISTS u_admin_pkey;
ALTER TABLE IF EXISTS ONLY public.t_target DROP CONSTRAINT IF EXISTS t_target_pkey;
ALTER TABLE IF EXISTS ONLY public.t_surah DROP CONSTRAINT IF EXISTS t_surah_pkey;
ALTER TABLE IF EXISTS ONLY public.t_surah DROP CONSTRAINT IF EXISTS t_surah_number_key;
ALTER TABLE IF EXISTS ONLY public.t_juz DROP CONSTRAINT IF EXISTS t_juz_pkey;
ALTER TABLE IF EXISTS ONLY public.t_juz DROP CONSTRAINT IF EXISTS t_juz_number_key;
ALTER TABLE IF EXISTS ONLY public.t_juz_detail DROP CONSTRAINT IF EXISTS t_juz_detail_pkey;
ALTER TABLE IF EXISTS ONLY public.t_halaqoh_students DROP CONSTRAINT IF EXISTS t_halaqoh_students_pkey;
ALTER TABLE IF EXISTS ONLY public.t_halaqoh DROP CONSTRAINT IF EXISTS t_halaqoh_pkey;
ALTER TABLE IF EXISTS ONLY public.t_exam DROP CONSTRAINT IF EXISTS t_exam_pkey;
ALTER TABLE IF EXISTS ONLY public.t_daily_record DROP CONSTRAINT IF EXISTS t_daily_record_pkey;
ALTER TABLE IF EXISTS ONLY public.t_activity_type DROP CONSTRAINT IF EXISTS t_activity_type_pkey;
ALTER TABLE IF EXISTS ONLY public.t_activity_type DROP CONSTRAINT IF EXISTS t_activity_type_code_key;
ALTER TABLE IF EXISTS ONLY public.sys_logs DROP CONSTRAINT IF EXISTS sys_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.l_score_weighting DROP CONSTRAINT IF EXISTS l_score_weighting_pkey;
ALTER TABLE IF EXISTS ONLY public.l_score_summative DROP CONSTRAINT IF EXISTS l_score_summative_pkey;
ALTER TABLE IF EXISTS ONLY public.l_score_formative DROP CONSTRAINT IF EXISTS l_score_formative_pkey;
ALTER TABLE IF EXISTS ONLY public.l_score_final DROP CONSTRAINT IF EXISTS l_score_final_pkey;
ALTER TABLE IF EXISTS ONLY public.l_score_attitude DROP CONSTRAINT IF EXISTS l_score_attitude_pkey;
ALTER TABLE IF EXISTS ONLY public.l_content DROP CONSTRAINT IF EXISTS l_content_pkey;
ALTER TABLE IF EXISTS ONLY public.l_chapter DROP CONSTRAINT IF EXISTS l_chapter_pkey;
ALTER TABLE IF EXISTS ONLY public.l_attendance DROP CONSTRAINT IF EXISTS l_attendance_pkey;
ALTER TABLE IF EXISTS ONLY public.db_village DROP CONSTRAINT IF EXISTS db_village_pkey;
ALTER TABLE IF EXISTS ONLY public.db_province DROP CONSTRAINT IF EXISTS db_province_pkey;
ALTER TABLE IF EXISTS ONLY public.db_district DROP CONSTRAINT IF EXISTS db_district_pkey;
ALTER TABLE IF EXISTS ONLY public.db_city DROP CONSTRAINT IF EXISTS db_city_pkey;
ALTER TABLE IF EXISTS ONLY public.c_student_session DROP CONSTRAINT IF EXISTS c_student_session_pkey;
ALTER TABLE IF EXISTS ONLY public.c_question DROP CONSTRAINT IF EXISTS c_question_pkey;
ALTER TABLE IF EXISTS ONLY public.c_question_options DROP CONSTRAINT IF EXISTS c_question_options_pkey;
ALTER TABLE IF EXISTS ONLY public.c_exam DROP CONSTRAINT IF EXISTS c_exam_pkey;
ALTER TABLE IF EXISTS ONLY public.c_exam_class DROP CONSTRAINT IF EXISTS c_exam_class_pkey;
ALTER TABLE IF EXISTS ONLY public.c_bank DROP CONSTRAINT IF EXISTS c_bank_pkey;
ALTER TABLE IF EXISTS ONLY public.c_answer DROP CONSTRAINT IF EXISTS c_answer_pkey;
ALTER TABLE IF EXISTS ONLY public.at_subject DROP CONSTRAINT IF EXISTS at_subject_pkey;
ALTER TABLE IF EXISTS ONLY public.a_subject DROP CONSTRAINT IF EXISTS a_subject_pkey;
ALTER TABLE IF EXISTS ONLY public.a_subject_category DROP CONSTRAINT IF EXISTS a_subject_category_pkey;
ALTER TABLE IF EXISTS ONLY public.a_periode DROP CONSTRAINT IF EXISTS a_periode_pkey;
ALTER TABLE IF EXISTS ONLY public.a_major DROP CONSTRAINT IF EXISTS a_major_pkey;
ALTER TABLE IF EXISTS ONLY public.a_homebase DROP CONSTRAINT IF EXISTS a_homebase_pkey;
ALTER TABLE IF EXISTS ONLY public.a_grade DROP CONSTRAINT IF EXISTS a_grade_pkey;
ALTER TABLE IF EXISTS ONLY public.a_class DROP CONSTRAINT IF EXISTS a_class_pkey;
ALTER TABLE IF EXISTS public.u_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.u_student_families ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_target ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_surah ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_juz_detail ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_juz ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_halaqoh_students ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_halaqoh ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_exam ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_daily_record ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.t_activity_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sys_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_score_weighting ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_score_summative ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_score_formative ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_score_final ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_score_attitude ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_content ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_chapter ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.l_attendance ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.c_student_session ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.c_question_options ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.c_question ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.c_exam_class ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.c_exam ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.c_bank ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.c_answer ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.at_subject ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.a_subject_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.a_subject ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.a_periode ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.a_major ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.a_homebase ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.a_grade ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.a_class ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.u_users_id_seq;
DROP TABLE IF EXISTS public.u_users;
DROP TABLE IF EXISTS public.u_teachers;
DROP TABLE IF EXISTS public.u_students;
DROP SEQUENCE IF EXISTS public.u_student_families_id_seq;
DROP TABLE IF EXISTS public.u_student_families;
DROP TABLE IF EXISTS public.u_parents;
DROP TABLE IF EXISTS public.u_admin;
DROP SEQUENCE IF EXISTS public.t_target_id_seq;
DROP TABLE IF EXISTS public.t_target;
DROP SEQUENCE IF EXISTS public.t_surah_id_seq;
DROP TABLE IF EXISTS public.t_surah;
DROP SEQUENCE IF EXISTS public.t_juz_id_seq;
DROP SEQUENCE IF EXISTS public.t_juz_detail_id_seq;
DROP TABLE IF EXISTS public.t_juz_detail;
DROP TABLE IF EXISTS public.t_juz;
DROP SEQUENCE IF EXISTS public.t_halaqoh_students_id_seq;
DROP TABLE IF EXISTS public.t_halaqoh_students;
DROP SEQUENCE IF EXISTS public.t_halaqoh_id_seq;
DROP TABLE IF EXISTS public.t_halaqoh;
DROP SEQUENCE IF EXISTS public.t_exam_id_seq;
DROP TABLE IF EXISTS public.t_exam;
DROP SEQUENCE IF EXISTS public.t_daily_record_id_seq;
DROP TABLE IF EXISTS public.t_daily_record;
DROP SEQUENCE IF EXISTS public.t_activity_type_id_seq;
DROP TABLE IF EXISTS public.t_activity_type;
DROP SEQUENCE IF EXISTS public.sys_logs_id_seq;
DROP TABLE IF EXISTS public.sys_logs;
DROP SEQUENCE IF EXISTS public.l_score_weighting_id_seq;
DROP TABLE IF EXISTS public.l_score_weighting;
DROP SEQUENCE IF EXISTS public.l_score_summative_id_seq;
DROP TABLE IF EXISTS public.l_score_summative;
DROP SEQUENCE IF EXISTS public.l_score_formative_id_seq;
DROP TABLE IF EXISTS public.l_score_formative;
DROP SEQUENCE IF EXISTS public.l_score_final_id_seq;
DROP TABLE IF EXISTS public.l_score_final;
DROP SEQUENCE IF EXISTS public.l_score_attitude_id_seq;
DROP TABLE IF EXISTS public.l_score_attitude;
DROP SEQUENCE IF EXISTS public.l_content_id_seq;
DROP TABLE IF EXISTS public.l_content;
DROP SEQUENCE IF EXISTS public.l_chapter_id_seq;
DROP TABLE IF EXISTS public.l_chapter;
DROP SEQUENCE IF EXISTS public.l_attendance_id_seq;
DROP TABLE IF EXISTS public.l_attendance;
DROP TABLE IF EXISTS public.db_village;
DROP TABLE IF EXISTS public.db_province;
DROP TABLE IF EXISTS public.db_district;
DROP TABLE IF EXISTS public.db_city;
DROP SEQUENCE IF EXISTS public.c_student_session_id_seq;
DROP TABLE IF EXISTS public.c_student_session;
DROP SEQUENCE IF EXISTS public.c_question_options_id_seq;
DROP TABLE IF EXISTS public.c_question_options;
DROP SEQUENCE IF EXISTS public.c_question_id_seq;
DROP TABLE IF EXISTS public.c_question;
DROP SEQUENCE IF EXISTS public.c_exam_id_seq;
DROP SEQUENCE IF EXISTS public.c_exam_class_id_seq;
DROP TABLE IF EXISTS public.c_exam_class;
DROP TABLE IF EXISTS public.c_exam;
DROP SEQUENCE IF EXISTS public.c_bank_id_seq;
DROP TABLE IF EXISTS public.c_bank;
DROP SEQUENCE IF EXISTS public.c_answer_id_seq;
DROP TABLE IF EXISTS public.c_answer;
DROP SEQUENCE IF EXISTS public.at_subject_id_seq;
DROP TABLE IF EXISTS public.at_subject;
DROP SEQUENCE IF EXISTS public.a_subject_id_seq;
DROP SEQUENCE IF EXISTS public.a_subject_category_id_seq;
DROP TABLE IF EXISTS public.a_subject_category;
DROP TABLE IF EXISTS public.a_subject;
DROP SEQUENCE IF EXISTS public.a_periode_id_seq;
DROP TABLE IF EXISTS public.a_periode;
DROP SEQUENCE IF EXISTS public.a_major_id_seq;
DROP TABLE IF EXISTS public.a_major;
DROP SEQUENCE IF EXISTS public.a_homebase_id_seq;
DROP TABLE IF EXISTS public.a_homebase;
DROP SEQUENCE IF EXISTS public.a_grade_id_seq;
DROP TABLE IF EXISTS public.a_grade;
DROP SEQUENCE IF EXISTS public.a_class_id_seq;
DROP TABLE IF EXISTS public.a_class;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: a_class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.a_class (
    id integer NOT NULL,
    homebase_id integer,
    grade_id integer,
    major_id integer,
    name text NOT NULL,
    homeroom_teacher_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.a_class OWNER TO postgres;

--
-- Name: a_class_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.a_class_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.a_class_id_seq OWNER TO postgres;

--
-- Name: a_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.a_class_id_seq OWNED BY public.a_class.id;


--
-- Name: a_grade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.a_grade (
    id integer NOT NULL,
    homebase_id integer,
    name text NOT NULL
);


ALTER TABLE public.a_grade OWNER TO postgres;

--
-- Name: a_grade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.a_grade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.a_grade_id_seq OWNER TO postgres;

--
-- Name: a_grade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.a_grade_id_seq OWNED BY public.a_grade.id;


--
-- Name: a_homebase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.a_homebase (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.a_homebase OWNER TO postgres;

--
-- Name: a_homebase_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.a_homebase_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.a_homebase_id_seq OWNER TO postgres;

--
-- Name: a_homebase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.a_homebase_id_seq OWNED BY public.a_homebase.id;


--
-- Name: a_major; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.a_major (
    id integer NOT NULL,
    homebase_id integer,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.a_major OWNER TO postgres;

--
-- Name: a_major_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.a_major_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.a_major_id_seq OWNER TO postgres;

--
-- Name: a_major_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.a_major_id_seq OWNED BY public.a_major.id;


--
-- Name: a_periode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.a_periode (
    id integer NOT NULL,
    homebase_id integer,
    name text NOT NULL,
    is_active boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.a_periode OWNER TO postgres;

--
-- Name: a_periode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.a_periode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.a_periode_id_seq OWNER TO postgres;

--
-- Name: a_periode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.a_periode_id_seq OWNED BY public.a_periode.id;


--
-- Name: a_subject; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.a_subject (
    id integer NOT NULL,
    homebase_id integer,
    category_id integer,
    name text NOT NULL,
    code text,
    kkm integer DEFAULT 75,
    cover_image text
);


ALTER TABLE public.a_subject OWNER TO postgres;

--
-- Name: a_subject_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.a_subject_category (
    id integer NOT NULL,
    homebase_id integer,
    name text NOT NULL
);


ALTER TABLE public.a_subject_category OWNER TO postgres;

--
-- Name: a_subject_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.a_subject_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.a_subject_category_id_seq OWNER TO postgres;

--
-- Name: a_subject_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.a_subject_category_id_seq OWNED BY public.a_subject_category.id;


--
-- Name: a_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.a_subject_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.a_subject_id_seq OWNER TO postgres;

--
-- Name: a_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.a_subject_id_seq OWNED BY public.a_subject.id;


--
-- Name: at_subject; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.at_subject (
    id integer NOT NULL,
    teacher_id integer,
    subject_id integer,
    class_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.at_subject OWNER TO postgres;

--
-- Name: at_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.at_subject_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.at_subject_id_seq OWNER TO postgres;

--
-- Name: at_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.at_subject_id_seq OWNED BY public.at_subject.id;


--
-- Name: c_answer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_answer (
    id integer NOT NULL,
    session_id integer,
    question_id integer,
    selected_option_id integer,
    essay_text text,
    is_correct boolean,
    score_obtained numeric(5,2)
);


ALTER TABLE public.c_answer OWNER TO postgres;

--
-- Name: c_answer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.c_answer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.c_answer_id_seq OWNER TO postgres;

--
-- Name: c_answer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.c_answer_id_seq OWNED BY public.c_answer.id;


--
-- Name: c_bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_bank (
    id integer NOT NULL,
    teacher_id integer,
    subject_id integer,
    title character varying(255) NOT NULL,
    type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.c_bank OWNER TO postgres;

--
-- Name: c_bank_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.c_bank_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.c_bank_id_seq OWNER TO postgres;

--
-- Name: c_bank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.c_bank_id_seq OWNED BY public.c_bank.id;


--
-- Name: c_exam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_exam (
    id integer NOT NULL,
    bank_id integer,
    name character varying(255) NOT NULL,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    duration_minutes integer NOT NULL,
    token character varying(10),
    is_active boolean DEFAULT true,
    is_shuffle boolean DEFAULT false,
    mc_score_weight integer DEFAULT 0,
    essay_score_weight integer DEFAULT 0
);


ALTER TABLE public.c_exam OWNER TO postgres;

--
-- Name: c_exam_class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_exam_class (
    id integer NOT NULL,
    exam_id integer,
    class_id integer
);


ALTER TABLE public.c_exam_class OWNER TO postgres;

--
-- Name: c_exam_class_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.c_exam_class_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.c_exam_class_id_seq OWNER TO postgres;

--
-- Name: c_exam_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.c_exam_class_id_seq OWNED BY public.c_exam_class.id;


--
-- Name: c_exam_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.c_exam_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.c_exam_id_seq OWNER TO postgres;

--
-- Name: c_exam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.c_exam_id_seq OWNED BY public.c_exam.id;


--
-- Name: c_question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_question (
    id integer NOT NULL,
    bank_id integer,
    q_type smallint NOT NULL,
    content text NOT NULL,
    media_url text,
    audio_url text,
    score_point integer DEFAULT 1
);


ALTER TABLE public.c_question OWNER TO postgres;

--
-- Name: c_question_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.c_question_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.c_question_id_seq OWNER TO postgres;

--
-- Name: c_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.c_question_id_seq OWNED BY public.c_question.id;


--
-- Name: c_question_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_question_options (
    id integer NOT NULL,
    question_id integer,
    label character varying(5),
    content text,
    media_url text,
    is_correct boolean DEFAULT false
);


ALTER TABLE public.c_question_options OWNER TO postgres;

--
-- Name: c_question_options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.c_question_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.c_question_options_id_seq OWNER TO postgres;

--
-- Name: c_question_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.c_question_options_id_seq OWNED BY public.c_question_options.id;


--
-- Name: c_student_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.c_student_session (
    id integer NOT NULL,
    exam_id integer,
    student_id integer,
    start_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    finish_time timestamp without time zone,
    score_final numeric(5,2)
);


ALTER TABLE public.c_student_session OWNER TO postgres;

--
-- Name: c_student_session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.c_student_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.c_student_session_id_seq OWNER TO postgres;

--
-- Name: c_student_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.c_student_session_id_seq OWNED BY public.c_student_session.id;


--
-- Name: db_city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_city (
    id character(4) NOT NULL,
    province_id character(2),
    name character varying(255) NOT NULL
);


ALTER TABLE public.db_city OWNER TO postgres;

--
-- Name: db_district; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_district (
    id character(7) NOT NULL,
    city_id character(4),
    name character varying(255) NOT NULL
);


ALTER TABLE public.db_district OWNER TO postgres;

--
-- Name: db_province; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_province (
    id character(2) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.db_province OWNER TO postgres;

--
-- Name: db_village; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_village (
    id character(20) NOT NULL,
    district_id character(7),
    name character varying(255) NOT NULL,
    postal_code character varying(10)
);


ALTER TABLE public.db_village OWNER TO postgres;

--
-- Name: l_attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_attendance (
    id integer NOT NULL,
    class_id integer,
    subject_id integer,
    student_id integer,
    date date DEFAULT CURRENT_DATE,
    status character varying(20),
    note text,
    teacher_id integer,
    CONSTRAINT l_attendance_status_check CHECK (((status)::text = ANY ((ARRAY['Hadir'::character varying, 'Izin'::character varying, 'Sakit'::character varying, 'Alpha'::character varying])::text[])))
);


ALTER TABLE public.l_attendance OWNER TO postgres;

--
-- Name: l_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_attendance_id_seq OWNER TO postgres;

--
-- Name: l_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_attendance_id_seq OWNED BY public.l_attendance.id;


--
-- Name: l_chapter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_chapter (
    id integer NOT NULL,
    subject_id integer,
    title text NOT NULL,
    description text,
    order_number integer
);


ALTER TABLE public.l_chapter OWNER TO postgres;

--
-- Name: l_chapter_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_chapter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_chapter_id_seq OWNER TO postgres;

--
-- Name: l_chapter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_chapter_id_seq OWNED BY public.l_chapter.id;


--
-- Name: l_content; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_content (
    id integer NOT NULL,
    chapter_id integer,
    title text NOT NULL,
    body text,
    video_url text,
    attachment_url text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.l_content OWNER TO postgres;

--
-- Name: l_content_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_content_id_seq OWNER TO postgres;

--
-- Name: l_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_content_id_seq OWNED BY public.l_content.id;


--
-- Name: l_score_attitude; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_score_attitude (
    id integer NOT NULL,
    student_id integer,
    subject_id integer,
    periode_id integer,
    month character varying(20),
    kinerja integer DEFAULT 0,
    kedisiplinan integer DEFAULT 0,
    keaktifan integer DEFAULT 0,
    percaya_diri integer DEFAULT 0,
    teacher_note text,
    average_score numeric(5,2) GENERATED ALWAYS AS ((((((kinerja + kedisiplinan) + keaktifan) + percaya_diri))::numeric / 4.0)) STORED
);


ALTER TABLE public.l_score_attitude OWNER TO postgres;

--
-- Name: l_score_attitude_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_score_attitude_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_score_attitude_id_seq OWNER TO postgres;

--
-- Name: l_score_attitude_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_score_attitude_id_seq OWNED BY public.l_score_attitude.id;


--
-- Name: l_score_final; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_score_final (
    id integer NOT NULL,
    periode_id integer,
    student_id integer,
    subject_id integer,
    final_grade integer,
    letter_grade character varying(2)
);


ALTER TABLE public.l_score_final OWNER TO postgres;

--
-- Name: l_score_final_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_score_final_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_score_final_id_seq OWNER TO postgres;

--
-- Name: l_score_final_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_score_final_id_seq OWNED BY public.l_score_final.id;


--
-- Name: l_score_formative; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_score_formative (
    id integer NOT NULL,
    student_id integer,
    subject_id integer,
    chapter_id integer,
    type character varying(50),
    score integer,
    CONSTRAINT l_score_formative_score_check CHECK (((score >= 0) AND (score <= 100)))
);


ALTER TABLE public.l_score_formative OWNER TO postgres;

--
-- Name: l_score_formative_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_score_formative_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_score_formative_id_seq OWNER TO postgres;

--
-- Name: l_score_formative_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_score_formative_id_seq OWNED BY public.l_score_formative.id;


--
-- Name: l_score_summative; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_score_summative (
    id integer NOT NULL,
    student_id integer,
    subject_id integer,
    periode_id integer,
    type character varying(20),
    score_written integer,
    score_skill integer,
    final_score numeric(5,2)
);


ALTER TABLE public.l_score_summative OWNER TO postgres;

--
-- Name: l_score_summative_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_score_summative_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_score_summative_id_seq OWNER TO postgres;

--
-- Name: l_score_summative_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_score_summative_id_seq OWNED BY public.l_score_summative.id;


--
-- Name: l_score_weighting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.l_score_weighting (
    id integer NOT NULL,
    teacher_id integer,
    subject_id integer,
    weight_attendance integer DEFAULT 0,
    weight_attitude integer DEFAULT 0,
    weight_daily integer DEFAULT 0,
    weight_mid integer DEFAULT 0,
    weight_final integer DEFAULT 0,
    CONSTRAINT total_weight_100 CHECK ((((((weight_attendance + weight_attitude) + weight_daily) + weight_mid) + weight_final) = 100))
);


ALTER TABLE public.l_score_weighting OWNER TO postgres;

--
-- Name: l_score_weighting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.l_score_weighting_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.l_score_weighting_id_seq OWNER TO postgres;

--
-- Name: l_score_weighting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.l_score_weighting_id_seq OWNED BY public.l_score_weighting.id;


--
-- Name: sys_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sys_logs (
    id integer NOT NULL,
    user_id integer,
    action text,
    ip_address text,
    browser text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sys_logs OWNER TO postgres;

--
-- Name: sys_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sys_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sys_logs_id_seq OWNER TO postgres;

--
-- Name: sys_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sys_logs_id_seq OWNED BY public.sys_logs.id;


--
-- Name: t_activity_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_activity_type (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    code character varying(10)
);


ALTER TABLE public.t_activity_type OWNER TO postgres;

--
-- Name: t_activity_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_activity_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_activity_type_id_seq OWNER TO postgres;

--
-- Name: t_activity_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_activity_type_id_seq OWNED BY public.t_activity_type.id;


--
-- Name: t_daily_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_daily_record (
    id integer NOT NULL,
    student_id integer,
    halaqoh_id integer,
    teacher_id integer,
    date date DEFAULT CURRENT_DATE,
    type_id integer,
    start_surah_id integer,
    start_ayat integer,
    end_surah_id integer,
    end_ayat integer,
    lines_count integer,
    fluency_grade character varying(2),
    tajweed_grade character varying(2),
    note text
);


ALTER TABLE public.t_daily_record OWNER TO postgres;

--
-- Name: t_daily_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_daily_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_daily_record_id_seq OWNER TO postgres;

--
-- Name: t_daily_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_daily_record_id_seq OWNED BY public.t_daily_record.id;


--
-- Name: t_exam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_exam (
    id integer NOT NULL,
    periode_id integer,
    student_id integer,
    examiner_id integer,
    date date DEFAULT CURRENT_DATE,
    title character varying(100),
    score_fashohah numeric(5,2),
    score_tajweed numeric(5,2),
    score_fluency numeric(5,2),
    final_score numeric(5,2),
    result_status character varying(20)
);


ALTER TABLE public.t_exam OWNER TO postgres;

--
-- Name: t_exam_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_exam_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_exam_id_seq OWNER TO postgres;

--
-- Name: t_exam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_exam_id_seq OWNED BY public.t_exam.id;


--
-- Name: t_halaqoh; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_halaqoh (
    id integer NOT NULL,
    periode_id integer,
    name character varying(100) NOT NULL,
    teacher_id integer,
    is_active boolean DEFAULT true
);


ALTER TABLE public.t_halaqoh OWNER TO postgres;

--
-- Name: t_halaqoh_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_halaqoh_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_halaqoh_id_seq OWNER TO postgres;

--
-- Name: t_halaqoh_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_halaqoh_id_seq OWNED BY public.t_halaqoh.id;


--
-- Name: t_halaqoh_students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_halaqoh_students (
    id integer NOT NULL,
    halaqoh_id integer,
    student_id integer
);


ALTER TABLE public.t_halaqoh_students OWNER TO postgres;

--
-- Name: t_halaqoh_students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_halaqoh_students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_halaqoh_students_id_seq OWNER TO postgres;

--
-- Name: t_halaqoh_students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_halaqoh_students_id_seq OWNED BY public.t_halaqoh_students.id;


--
-- Name: t_juz; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_juz (
    id integer NOT NULL,
    number integer NOT NULL,
    description text
);


ALTER TABLE public.t_juz OWNER TO postgres;

--
-- Name: t_juz_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_juz_detail (
    id integer NOT NULL,
    juz_id integer,
    surah_id integer,
    start_ayat integer,
    end_ayat integer
);


ALTER TABLE public.t_juz_detail OWNER TO postgres;

--
-- Name: t_juz_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_juz_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_juz_detail_id_seq OWNER TO postgres;

--
-- Name: t_juz_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_juz_detail_id_seq OWNED BY public.t_juz_detail.id;


--
-- Name: t_juz_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_juz_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_juz_id_seq OWNER TO postgres;

--
-- Name: t_juz_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_juz_id_seq OWNED BY public.t_juz.id;


--
-- Name: t_surah; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_surah (
    id integer NOT NULL,
    number integer NOT NULL,
    name_latin character varying(100) NOT NULL,
    total_ayat integer NOT NULL
);


ALTER TABLE public.t_surah OWNER TO postgres;

--
-- Name: t_surah_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_surah_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_surah_id_seq OWNER TO postgres;

--
-- Name: t_surah_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_surah_id_seq OWNED BY public.t_surah.id;


--
-- Name: t_target; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_target (
    id integer NOT NULL,
    periode_id integer,
    grade_id integer,
    juz_id integer,
    description text
);


ALTER TABLE public.t_target OWNER TO postgres;

--
-- Name: t_target_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_target_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.t_target_id_seq OWNER TO postgres;

--
-- Name: t_target_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_target_id_seq OWNED BY public.t_target.id;


--
-- Name: u_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.u_admin (
    user_id integer NOT NULL,
    phone text,
    email text,
    level text DEFAULT 'admin'::text
);


ALTER TABLE public.u_admin OWNER TO postgres;

--
-- Name: u_parents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.u_parents (
    user_id integer NOT NULL,
    student_id integer,
    phone text,
    email text
);


ALTER TABLE public.u_parents OWNER TO postgres;

--
-- Name: u_student_families; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.u_student_families (
    id integer NOT NULL,
    student_id integer,
    father_nik character varying(50),
    father_name character varying(255),
    father_birth_place character varying(255),
    father_birth_date date,
    father_job text,
    father_phone text,
    mother_nik character varying(50),
    mother_name character varying(255),
    mother_birth_place character varying(255),
    mother_birth_date date,
    mother_job text,
    mother_phone text,
    guardian_name character varying(255),
    guardian_phone text
);


ALTER TABLE public.u_student_families OWNER TO postgres;

--
-- Name: u_student_families_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.u_student_families_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.u_student_families_id_seq OWNER TO postgres;

--
-- Name: u_student_families_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.u_student_families_id_seq OWNED BY public.u_student_families.id;


--
-- Name: u_students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.u_students (
    user_id integer NOT NULL,
    nis text,
    nisn text,
    homebase_id integer,
    current_class_id integer,
    current_periode_id integer,
    birth_place text,
    birth_date date,
    height text,
    weight text,
    head_circumference text,
    order_number integer,
    siblings_count integer,
    address text,
    province_id character(2),
    city_id character(4),
    district_id character(7),
    village_id character(20),
    postal_code text
);


ALTER TABLE public.u_students OWNER TO postgres;

--
-- Name: u_teachers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.u_teachers (
    user_id integer NOT NULL,
    nip text,
    phone text,
    email text,
    homebase_id integer,
    is_homeroom boolean DEFAULT false
);


ALTER TABLE public.u_teachers OWNER TO postgres;

--
-- Name: u_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.u_users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    full_name text NOT NULL,
    role character varying(20) NOT NULL,
    img_url text,
    gender character varying(10),
    is_active boolean DEFAULT true,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT u_users_role_check CHECK (((role)::text = ANY ((ARRAY['student'::character varying, 'teacher'::character varying, 'admin'::character varying, 'parent'::character varying, 'center'::character varying])::text[])))
);


ALTER TABLE public.u_users OWNER TO postgres;

--
-- Name: u_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.u_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.u_users_id_seq OWNER TO postgres;

--
-- Name: u_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.u_users_id_seq OWNED BY public.u_users.id;


--
-- Name: a_class id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_class ALTER COLUMN id SET DEFAULT nextval('public.a_class_id_seq'::regclass);


--
-- Name: a_grade id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_grade ALTER COLUMN id SET DEFAULT nextval('public.a_grade_id_seq'::regclass);


--
-- Name: a_homebase id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_homebase ALTER COLUMN id SET DEFAULT nextval('public.a_homebase_id_seq'::regclass);


--
-- Name: a_major id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_major ALTER COLUMN id SET DEFAULT nextval('public.a_major_id_seq'::regclass);


--
-- Name: a_periode id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_periode ALTER COLUMN id SET DEFAULT nextval('public.a_periode_id_seq'::regclass);


--
-- Name: a_subject id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_subject ALTER COLUMN id SET DEFAULT nextval('public.a_subject_id_seq'::regclass);


--
-- Name: a_subject_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_subject_category ALTER COLUMN id SET DEFAULT nextval('public.a_subject_category_id_seq'::regclass);


--
-- Name: at_subject id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.at_subject ALTER COLUMN id SET DEFAULT nextval('public.at_subject_id_seq'::regclass);


--
-- Name: c_answer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_answer ALTER COLUMN id SET DEFAULT nextval('public.c_answer_id_seq'::regclass);


--
-- Name: c_bank id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_bank ALTER COLUMN id SET DEFAULT nextval('public.c_bank_id_seq'::regclass);


--
-- Name: c_exam id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_exam ALTER COLUMN id SET DEFAULT nextval('public.c_exam_id_seq'::regclass);


--
-- Name: c_exam_class id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_exam_class ALTER COLUMN id SET DEFAULT nextval('public.c_exam_class_id_seq'::regclass);


--
-- Name: c_question id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_question ALTER COLUMN id SET DEFAULT nextval('public.c_question_id_seq'::regclass);


--
-- Name: c_question_options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_question_options ALTER COLUMN id SET DEFAULT nextval('public.c_question_options_id_seq'::regclass);


--
-- Name: c_student_session id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_student_session ALTER COLUMN id SET DEFAULT nextval('public.c_student_session_id_seq'::regclass);


--
-- Name: l_attendance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_attendance ALTER COLUMN id SET DEFAULT nextval('public.l_attendance_id_seq'::regclass);


--
-- Name: l_chapter id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_chapter ALTER COLUMN id SET DEFAULT nextval('public.l_chapter_id_seq'::regclass);


--
-- Name: l_content id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_content ALTER COLUMN id SET DEFAULT nextval('public.l_content_id_seq'::regclass);


--
-- Name: l_score_attitude id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_attitude ALTER COLUMN id SET DEFAULT nextval('public.l_score_attitude_id_seq'::regclass);


--
-- Name: l_score_final id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_final ALTER COLUMN id SET DEFAULT nextval('public.l_score_final_id_seq'::regclass);


--
-- Name: l_score_formative id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_formative ALTER COLUMN id SET DEFAULT nextval('public.l_score_formative_id_seq'::regclass);


--
-- Name: l_score_summative id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_summative ALTER COLUMN id SET DEFAULT nextval('public.l_score_summative_id_seq'::regclass);


--
-- Name: l_score_weighting id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_weighting ALTER COLUMN id SET DEFAULT nextval('public.l_score_weighting_id_seq'::regclass);


--
-- Name: sys_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_logs ALTER COLUMN id SET DEFAULT nextval('public.sys_logs_id_seq'::regclass);


--
-- Name: t_activity_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_activity_type ALTER COLUMN id SET DEFAULT nextval('public.t_activity_type_id_seq'::regclass);


--
-- Name: t_daily_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record ALTER COLUMN id SET DEFAULT nextval('public.t_daily_record_id_seq'::regclass);


--
-- Name: t_exam id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_exam ALTER COLUMN id SET DEFAULT nextval('public.t_exam_id_seq'::regclass);


--
-- Name: t_halaqoh id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh ALTER COLUMN id SET DEFAULT nextval('public.t_halaqoh_id_seq'::regclass);


--
-- Name: t_halaqoh_students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh_students ALTER COLUMN id SET DEFAULT nextval('public.t_halaqoh_students_id_seq'::regclass);


--
-- Name: t_juz id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_juz ALTER COLUMN id SET DEFAULT nextval('public.t_juz_id_seq'::regclass);


--
-- Name: t_juz_detail id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_juz_detail ALTER COLUMN id SET DEFAULT nextval('public.t_juz_detail_id_seq'::regclass);


--
-- Name: t_surah id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_surah ALTER COLUMN id SET DEFAULT nextval('public.t_surah_id_seq'::regclass);


--
-- Name: t_target id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_target ALTER COLUMN id SET DEFAULT nextval('public.t_target_id_seq'::regclass);


--
-- Name: u_student_families id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_student_families ALTER COLUMN id SET DEFAULT nextval('public.u_student_families_id_seq'::regclass);


--
-- Name: u_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_users ALTER COLUMN id SET DEFAULT nextval('public.u_users_id_seq'::regclass);


--
-- Data for Name: a_class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.a_class (id, homebase_id, grade_id, major_id, name, homeroom_teacher_id, created_at) FROM stdin;
\.


--
-- Data for Name: a_grade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.a_grade (id, homebase_id, name) FROM stdin;
\.


--
-- Data for Name: a_homebase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.a_homebase (id, name, description, created_at) FROM stdin;
\.


--
-- Data for Name: a_major; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.a_major (id, homebase_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: a_periode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.a_periode (id, homebase_id, name, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: a_subject; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.a_subject (id, homebase_id, category_id, name, code, kkm, cover_image) FROM stdin;
\.


--
-- Data for Name: a_subject_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.a_subject_category (id, homebase_id, name) FROM stdin;
\.


--
-- Data for Name: at_subject; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.at_subject (id, teacher_id, subject_id, class_id, created_at) FROM stdin;
\.


--
-- Data for Name: c_answer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_answer (id, session_id, question_id, selected_option_id, essay_text, is_correct, score_obtained) FROM stdin;
\.


--
-- Data for Name: c_bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_bank (id, teacher_id, subject_id, title, type, created_at) FROM stdin;
\.


--
-- Data for Name: c_exam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_exam (id, bank_id, name, start_time, end_time, duration_minutes, token, is_active, is_shuffle, mc_score_weight, essay_score_weight) FROM stdin;
\.


--
-- Data for Name: c_exam_class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_exam_class (id, exam_id, class_id) FROM stdin;
\.


--
-- Data for Name: c_question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_question (id, bank_id, q_type, content, media_url, audio_url, score_point) FROM stdin;
\.


--
-- Data for Name: c_question_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_question_options (id, question_id, label, content, media_url, is_correct) FROM stdin;
\.


--
-- Data for Name: c_student_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.c_student_session (id, exam_id, student_id, start_time, finish_time, score_final) FROM stdin;
\.


--
-- Data for Name: db_city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.db_city (id, province_id, name) FROM stdin;
\.


--
-- Data for Name: db_district; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.db_district (id, city_id, name) FROM stdin;
\.


--
-- Data for Name: db_province; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.db_province (id, name) FROM stdin;
\.


--
-- Data for Name: db_village; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.db_village (id, district_id, name, postal_code) FROM stdin;
\.


--
-- Data for Name: l_attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_attendance (id, class_id, subject_id, student_id, date, status, note, teacher_id) FROM stdin;
\.


--
-- Data for Name: l_chapter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_chapter (id, subject_id, title, description, order_number) FROM stdin;
\.


--
-- Data for Name: l_content; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_content (id, chapter_id, title, body, video_url, attachment_url, created_at) FROM stdin;
\.


--
-- Data for Name: l_score_attitude; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_score_attitude (id, student_id, subject_id, periode_id, month, kinerja, kedisiplinan, keaktifan, percaya_diri, teacher_note) FROM stdin;
\.


--
-- Data for Name: l_score_final; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_score_final (id, periode_id, student_id, subject_id, final_grade, letter_grade) FROM stdin;
\.


--
-- Data for Name: l_score_formative; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_score_formative (id, student_id, subject_id, chapter_id, type, score) FROM stdin;
\.


--
-- Data for Name: l_score_summative; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_score_summative (id, student_id, subject_id, periode_id, type, score_written, score_skill, final_score) FROM stdin;
\.


--
-- Data for Name: l_score_weighting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.l_score_weighting (id, teacher_id, subject_id, weight_attendance, weight_attitude, weight_daily, weight_mid, weight_final) FROM stdin;
\.


--
-- Data for Name: sys_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sys_logs (id, user_id, action, ip_address, browser, created_at) FROM stdin;
1	1	login	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	2026-01-19 19:29:51.428089
2	1	login	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	2026-01-19 19:30:29.703525
3	1	login	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	2026-01-19 19:33:15.539479
4	1	login	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	2026-01-19 19:36:00.961248
\.


--
-- Data for Name: t_activity_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_activity_type (id, name, code) FROM stdin;
\.


--
-- Data for Name: t_daily_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_daily_record (id, student_id, halaqoh_id, teacher_id, date, type_id, start_surah_id, start_ayat, end_surah_id, end_ayat, lines_count, fluency_grade, tajweed_grade, note) FROM stdin;
\.


--
-- Data for Name: t_exam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_exam (id, periode_id, student_id, examiner_id, date, title, score_fashohah, score_tajweed, score_fluency, final_score, result_status) FROM stdin;
\.


--
-- Data for Name: t_halaqoh; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_halaqoh (id, periode_id, name, teacher_id, is_active) FROM stdin;
\.


--
-- Data for Name: t_halaqoh_students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_halaqoh_students (id, halaqoh_id, student_id) FROM stdin;
\.


--
-- Data for Name: t_juz; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_juz (id, number, description) FROM stdin;
\.


--
-- Data for Name: t_juz_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_juz_detail (id, juz_id, surah_id, start_ayat, end_ayat) FROM stdin;
\.


--
-- Data for Name: t_surah; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_surah (id, number, name_latin, total_ayat) FROM stdin;
\.


--
-- Data for Name: t_target; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_target (id, periode_id, grade_id, juz_id, description) FROM stdin;
\.


--
-- Data for Name: u_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.u_admin (user_id, phone, email, level) FROM stdin;
1	\N	center@nibs.sch.id	pusat
\.


--
-- Data for Name: u_parents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.u_parents (user_id, student_id, phone, email) FROM stdin;
\.


--
-- Data for Name: u_student_families; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.u_student_families (id, student_id, father_nik, father_name, father_birth_place, father_birth_date, father_job, father_phone, mother_nik, mother_name, mother_birth_place, mother_birth_date, mother_job, mother_phone, guardian_name, guardian_phone) FROM stdin;
\.


--
-- Data for Name: u_students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.u_students (user_id, nis, nisn, homebase_id, current_class_id, current_periode_id, birth_place, birth_date, height, weight, head_circumference, order_number, siblings_count, address, province_id, city_id, district_id, village_id, postal_code) FROM stdin;
\.


--
-- Data for Name: u_teachers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.u_teachers (user_id, nip, phone, email, homebase_id, is_homeroom) FROM stdin;
\.


--
-- Data for Name: u_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.u_users (id, username, password, full_name, role, img_url, gender, is_active, last_login, created_at) FROM stdin;
1	center	$2b$10$KF/K0lZeMzOx304KFm8rmu0zoSWI1/faWD/K6LyqmeIH8lPz41xNS	Admin Pusat	admin	\N	\N	t	2026-01-19 19:36:00.961248	2026-01-19 18:18:09.690988
\.


--
-- Name: a_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.a_class_id_seq', 1, false);


--
-- Name: a_grade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.a_grade_id_seq', 1, false);


--
-- Name: a_homebase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.a_homebase_id_seq', 1, false);


--
-- Name: a_major_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.a_major_id_seq', 1, false);


--
-- Name: a_periode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.a_periode_id_seq', 1, false);


--
-- Name: a_subject_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.a_subject_category_id_seq', 1, false);


--
-- Name: a_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.a_subject_id_seq', 1, false);


--
-- Name: at_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.at_subject_id_seq', 1, false);


--
-- Name: c_answer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_answer_id_seq', 1, false);


--
-- Name: c_bank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_bank_id_seq', 1, false);


--
-- Name: c_exam_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_exam_class_id_seq', 1, false);


--
-- Name: c_exam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_exam_id_seq', 1, false);


--
-- Name: c_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_question_id_seq', 1, false);


--
-- Name: c_question_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_question_options_id_seq', 1, false);


--
-- Name: c_student_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_student_session_id_seq', 1, false);


--
-- Name: l_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_attendance_id_seq', 1, false);


--
-- Name: l_chapter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_chapter_id_seq', 1, false);


--
-- Name: l_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_content_id_seq', 1, false);


--
-- Name: l_score_attitude_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_score_attitude_id_seq', 1, false);


--
-- Name: l_score_final_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_score_final_id_seq', 1, false);


--
-- Name: l_score_formative_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_score_formative_id_seq', 1, false);


--
-- Name: l_score_summative_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_score_summative_id_seq', 1, false);


--
-- Name: l_score_weighting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.l_score_weighting_id_seq', 1, false);


--
-- Name: sys_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sys_logs_id_seq', 4, true);


--
-- Name: t_activity_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_activity_type_id_seq', 1, false);


--
-- Name: t_daily_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_daily_record_id_seq', 1, false);


--
-- Name: t_exam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_exam_id_seq', 1, false);


--
-- Name: t_halaqoh_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_halaqoh_id_seq', 1, false);


--
-- Name: t_halaqoh_students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_halaqoh_students_id_seq', 1, false);


--
-- Name: t_juz_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_juz_detail_id_seq', 1, false);


--
-- Name: t_juz_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_juz_id_seq', 1, false);


--
-- Name: t_surah_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_surah_id_seq', 1, false);


--
-- Name: t_target_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_target_id_seq', 1, false);


--
-- Name: u_student_families_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.u_student_families_id_seq', 1, false);


--
-- Name: u_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.u_users_id_seq', 1, true);


--
-- Name: a_class a_class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_class
    ADD CONSTRAINT a_class_pkey PRIMARY KEY (id);


--
-- Name: a_grade a_grade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_grade
    ADD CONSTRAINT a_grade_pkey PRIMARY KEY (id);


--
-- Name: a_homebase a_homebase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_homebase
    ADD CONSTRAINT a_homebase_pkey PRIMARY KEY (id);


--
-- Name: a_major a_major_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_major
    ADD CONSTRAINT a_major_pkey PRIMARY KEY (id);


--
-- Name: a_periode a_periode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_periode
    ADD CONSTRAINT a_periode_pkey PRIMARY KEY (id);


--
-- Name: a_subject_category a_subject_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_subject_category
    ADD CONSTRAINT a_subject_category_pkey PRIMARY KEY (id);


--
-- Name: a_subject a_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_subject
    ADD CONSTRAINT a_subject_pkey PRIMARY KEY (id);


--
-- Name: at_subject at_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.at_subject
    ADD CONSTRAINT at_subject_pkey PRIMARY KEY (id);


--
-- Name: c_answer c_answer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_answer
    ADD CONSTRAINT c_answer_pkey PRIMARY KEY (id);


--
-- Name: c_bank c_bank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_bank
    ADD CONSTRAINT c_bank_pkey PRIMARY KEY (id);


--
-- Name: c_exam_class c_exam_class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_exam_class
    ADD CONSTRAINT c_exam_class_pkey PRIMARY KEY (id);


--
-- Name: c_exam c_exam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_exam
    ADD CONSTRAINT c_exam_pkey PRIMARY KEY (id);


--
-- Name: c_question_options c_question_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_question_options
    ADD CONSTRAINT c_question_options_pkey PRIMARY KEY (id);


--
-- Name: c_question c_question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_question
    ADD CONSTRAINT c_question_pkey PRIMARY KEY (id);


--
-- Name: c_student_session c_student_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_student_session
    ADD CONSTRAINT c_student_session_pkey PRIMARY KEY (id);


--
-- Name: db_city db_city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_city
    ADD CONSTRAINT db_city_pkey PRIMARY KEY (id);


--
-- Name: db_district db_district_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_district
    ADD CONSTRAINT db_district_pkey PRIMARY KEY (id);


--
-- Name: db_province db_province_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_province
    ADD CONSTRAINT db_province_pkey PRIMARY KEY (id);


--
-- Name: db_village db_village_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_village
    ADD CONSTRAINT db_village_pkey PRIMARY KEY (id);


--
-- Name: l_attendance l_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_attendance
    ADD CONSTRAINT l_attendance_pkey PRIMARY KEY (id);


--
-- Name: l_chapter l_chapter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_chapter
    ADD CONSTRAINT l_chapter_pkey PRIMARY KEY (id);


--
-- Name: l_content l_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_content
    ADD CONSTRAINT l_content_pkey PRIMARY KEY (id);


--
-- Name: l_score_attitude l_score_attitude_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_attitude
    ADD CONSTRAINT l_score_attitude_pkey PRIMARY KEY (id);


--
-- Name: l_score_final l_score_final_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_final
    ADD CONSTRAINT l_score_final_pkey PRIMARY KEY (id);


--
-- Name: l_score_formative l_score_formative_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_formative
    ADD CONSTRAINT l_score_formative_pkey PRIMARY KEY (id);


--
-- Name: l_score_summative l_score_summative_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_summative
    ADD CONSTRAINT l_score_summative_pkey PRIMARY KEY (id);


--
-- Name: l_score_weighting l_score_weighting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_weighting
    ADD CONSTRAINT l_score_weighting_pkey PRIMARY KEY (id);


--
-- Name: sys_logs sys_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sys_logs
    ADD CONSTRAINT sys_logs_pkey PRIMARY KEY (id);


--
-- Name: t_activity_type t_activity_type_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_activity_type
    ADD CONSTRAINT t_activity_type_code_key UNIQUE (code);


--
-- Name: t_activity_type t_activity_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_activity_type
    ADD CONSTRAINT t_activity_type_pkey PRIMARY KEY (id);


--
-- Name: t_daily_record t_daily_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record
    ADD CONSTRAINT t_daily_record_pkey PRIMARY KEY (id);


--
-- Name: t_exam t_exam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_exam
    ADD CONSTRAINT t_exam_pkey PRIMARY KEY (id);


--
-- Name: t_halaqoh t_halaqoh_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh
    ADD CONSTRAINT t_halaqoh_pkey PRIMARY KEY (id);


--
-- Name: t_halaqoh_students t_halaqoh_students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh_students
    ADD CONSTRAINT t_halaqoh_students_pkey PRIMARY KEY (id);


--
-- Name: t_juz_detail t_juz_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_juz_detail
    ADD CONSTRAINT t_juz_detail_pkey PRIMARY KEY (id);


--
-- Name: t_juz t_juz_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_juz
    ADD CONSTRAINT t_juz_number_key UNIQUE (number);


--
-- Name: t_juz t_juz_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_juz
    ADD CONSTRAINT t_juz_pkey PRIMARY KEY (id);


--
-- Name: t_surah t_surah_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_surah
    ADD CONSTRAINT t_surah_number_key UNIQUE (number);


--
-- Name: t_surah t_surah_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_surah
    ADD CONSTRAINT t_surah_pkey PRIMARY KEY (id);


--
-- Name: t_target t_target_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_target
    ADD CONSTRAINT t_target_pkey PRIMARY KEY (id);


--
-- Name: u_admin u_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_admin
    ADD CONSTRAINT u_admin_pkey PRIMARY KEY (user_id);


--
-- Name: u_parents u_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_parents
    ADD CONSTRAINT u_parents_pkey PRIMARY KEY (user_id);


--
-- Name: u_student_families u_student_families_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_student_families
    ADD CONSTRAINT u_student_families_pkey PRIMARY KEY (id);


--
-- Name: u_students u_students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_students
    ADD CONSTRAINT u_students_pkey PRIMARY KEY (user_id);


--
-- Name: u_teachers u_teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_teachers
    ADD CONSTRAINT u_teachers_pkey PRIMARY KEY (user_id);


--
-- Name: u_users u_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_users
    ADD CONSTRAINT u_users_pkey PRIMARY KEY (id);


--
-- Name: u_users u_users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_users
    ADD CONSTRAINT u_users_username_key UNIQUE (username);


--
-- Name: a_class a_class_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_class
    ADD CONSTRAINT a_class_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.a_grade(id);


--
-- Name: a_class a_class_homebase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_class
    ADD CONSTRAINT a_class_homebase_id_fkey FOREIGN KEY (homebase_id) REFERENCES public.a_homebase(id);


--
-- Name: a_class a_class_homeroom_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_class
    ADD CONSTRAINT a_class_homeroom_teacher_id_fkey FOREIGN KEY (homeroom_teacher_id) REFERENCES public.u_teachers(user_id);


--
-- Name: a_class a_class_major_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_class
    ADD CONSTRAINT a_class_major_id_fkey FOREIGN KEY (major_id) REFERENCES public.a_major(id);


--
-- Name: a_grade a_grade_homebase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_grade
    ADD CONSTRAINT a_grade_homebase_id_fkey FOREIGN KEY (homebase_id) REFERENCES public.a_homebase(id);


--
-- Name: a_major a_major_homebase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_major
    ADD CONSTRAINT a_major_homebase_id_fkey FOREIGN KEY (homebase_id) REFERENCES public.a_homebase(id);


--
-- Name: a_periode a_periode_homebase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_periode
    ADD CONSTRAINT a_periode_homebase_id_fkey FOREIGN KEY (homebase_id) REFERENCES public.a_homebase(id);


--
-- Name: a_subject_category a_subject_category_homebase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_subject_category
    ADD CONSTRAINT a_subject_category_homebase_id_fkey FOREIGN KEY (homebase_id) REFERENCES public.a_homebase(id);


--
-- Name: a_subject a_subject_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_subject
    ADD CONSTRAINT a_subject_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.a_subject_category(id);


--
-- Name: a_subject a_subject_homebase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.a_subject
    ADD CONSTRAINT a_subject_homebase_id_fkey FOREIGN KEY (homebase_id) REFERENCES public.a_homebase(id);


--
-- Name: at_subject at_subject_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.at_subject
    ADD CONSTRAINT at_subject_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.a_class(id);


--
-- Name: at_subject at_subject_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.at_subject
    ADD CONSTRAINT at_subject_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: at_subject at_subject_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.at_subject
    ADD CONSTRAINT at_subject_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.u_teachers(user_id);


--
-- Name: c_answer c_answer_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_answer
    ADD CONSTRAINT c_answer_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.c_question(id);


--
-- Name: c_answer c_answer_selected_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_answer
    ADD CONSTRAINT c_answer_selected_option_id_fkey FOREIGN KEY (selected_option_id) REFERENCES public.c_question_options(id);


--
-- Name: c_answer c_answer_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_answer
    ADD CONSTRAINT c_answer_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.c_student_session(id);


--
-- Name: c_bank c_bank_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_bank
    ADD CONSTRAINT c_bank_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: c_bank c_bank_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_bank
    ADD CONSTRAINT c_bank_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.u_teachers(user_id);


--
-- Name: c_exam c_exam_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_exam
    ADD CONSTRAINT c_exam_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.c_bank(id);


--
-- Name: c_exam_class c_exam_class_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_exam_class
    ADD CONSTRAINT c_exam_class_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.a_class(id) ON DELETE CASCADE;


--
-- Name: c_exam_class c_exam_class_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_exam_class
    ADD CONSTRAINT c_exam_class_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.c_exam(id) ON DELETE CASCADE;


--
-- Name: c_question c_question_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_question
    ADD CONSTRAINT c_question_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.c_bank(id) ON DELETE CASCADE;


--
-- Name: c_question_options c_question_options_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_question_options
    ADD CONSTRAINT c_question_options_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.c_question(id) ON DELETE CASCADE;


--
-- Name: c_student_session c_student_session_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_student_session
    ADD CONSTRAINT c_student_session_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.c_exam(id);


--
-- Name: c_student_session c_student_session_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.c_student_session
    ADD CONSTRAINT c_student_session_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: db_city db_city_province_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_city
    ADD CONSTRAINT db_city_province_id_fkey FOREIGN KEY (province_id) REFERENCES public.db_province(id);


--
-- Name: db_district db_district_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_district
    ADD CONSTRAINT db_district_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.db_city(id);


--
-- Name: db_village db_village_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_village
    ADD CONSTRAINT db_village_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.db_district(id);


--
-- Name: l_attendance l_attendance_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_attendance
    ADD CONSTRAINT l_attendance_class_id_fkey FOREIGN KEY (class_id) REFERENCES public.a_class(id);


--
-- Name: l_attendance l_attendance_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_attendance
    ADD CONSTRAINT l_attendance_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: l_attendance l_attendance_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_attendance
    ADD CONSTRAINT l_attendance_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: l_attendance l_attendance_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_attendance
    ADD CONSTRAINT l_attendance_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.u_teachers(user_id);


--
-- Name: l_chapter l_chapter_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_chapter
    ADD CONSTRAINT l_chapter_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: l_content l_content_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_content
    ADD CONSTRAINT l_content_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.l_chapter(id);


--
-- Name: l_score_attitude l_score_attitude_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_attitude
    ADD CONSTRAINT l_score_attitude_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.a_periode(id);


--
-- Name: l_score_attitude l_score_attitude_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_attitude
    ADD CONSTRAINT l_score_attitude_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: l_score_attitude l_score_attitude_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_attitude
    ADD CONSTRAINT l_score_attitude_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: l_score_final l_score_final_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_final
    ADD CONSTRAINT l_score_final_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.a_periode(id);


--
-- Name: l_score_final l_score_final_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_final
    ADD CONSTRAINT l_score_final_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: l_score_final l_score_final_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_final
    ADD CONSTRAINT l_score_final_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: l_score_formative l_score_formative_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_formative
    ADD CONSTRAINT l_score_formative_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.l_chapter(id);


--
-- Name: l_score_formative l_score_formative_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_formative
    ADD CONSTRAINT l_score_formative_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: l_score_formative l_score_formative_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_formative
    ADD CONSTRAINT l_score_formative_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: l_score_summative l_score_summative_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_summative
    ADD CONSTRAINT l_score_summative_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.a_periode(id);


--
-- Name: l_score_summative l_score_summative_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_summative
    ADD CONSTRAINT l_score_summative_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: l_score_summative l_score_summative_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_summative
    ADD CONSTRAINT l_score_summative_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: l_score_weighting l_score_weighting_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_weighting
    ADD CONSTRAINT l_score_weighting_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.a_subject(id);


--
-- Name: l_score_weighting l_score_weighting_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.l_score_weighting
    ADD CONSTRAINT l_score_weighting_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.u_teachers(user_id);


--
-- Name: t_daily_record t_daily_record_end_surah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record
    ADD CONSTRAINT t_daily_record_end_surah_id_fkey FOREIGN KEY (end_surah_id) REFERENCES public.t_surah(id);


--
-- Name: t_daily_record t_daily_record_halaqoh_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record
    ADD CONSTRAINT t_daily_record_halaqoh_id_fkey FOREIGN KEY (halaqoh_id) REFERENCES public.t_halaqoh(id);


--
-- Name: t_daily_record t_daily_record_start_surah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record
    ADD CONSTRAINT t_daily_record_start_surah_id_fkey FOREIGN KEY (start_surah_id) REFERENCES public.t_surah(id);


--
-- Name: t_daily_record t_daily_record_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record
    ADD CONSTRAINT t_daily_record_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: t_daily_record t_daily_record_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record
    ADD CONSTRAINT t_daily_record_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.u_teachers(user_id);


--
-- Name: t_daily_record t_daily_record_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_daily_record
    ADD CONSTRAINT t_daily_record_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.t_activity_type(id);


--
-- Name: t_exam t_exam_examiner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_exam
    ADD CONSTRAINT t_exam_examiner_id_fkey FOREIGN KEY (examiner_id) REFERENCES public.u_teachers(user_id);


--
-- Name: t_exam t_exam_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_exam
    ADD CONSTRAINT t_exam_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.a_periode(id);


--
-- Name: t_exam t_exam_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_exam
    ADD CONSTRAINT t_exam_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: t_halaqoh t_halaqoh_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh
    ADD CONSTRAINT t_halaqoh_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.a_periode(id);


--
-- Name: t_halaqoh_students t_halaqoh_students_halaqoh_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh_students
    ADD CONSTRAINT t_halaqoh_students_halaqoh_id_fkey FOREIGN KEY (halaqoh_id) REFERENCES public.t_halaqoh(id);


--
-- Name: t_halaqoh_students t_halaqoh_students_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh_students
    ADD CONSTRAINT t_halaqoh_students_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: t_halaqoh t_halaqoh_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_halaqoh
    ADD CONSTRAINT t_halaqoh_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.u_teachers(user_id);


--
-- Name: t_juz_detail t_juz_detail_juz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_juz_detail
    ADD CONSTRAINT t_juz_detail_juz_id_fkey FOREIGN KEY (juz_id) REFERENCES public.t_juz(id);


--
-- Name: t_juz_detail t_juz_detail_surah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_juz_detail
    ADD CONSTRAINT t_juz_detail_surah_id_fkey FOREIGN KEY (surah_id) REFERENCES public.t_surah(id);


--
-- Name: t_target t_target_grade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_target
    ADD CONSTRAINT t_target_grade_id_fkey FOREIGN KEY (grade_id) REFERENCES public.a_grade(id);


--
-- Name: t_target t_target_juz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_target
    ADD CONSTRAINT t_target_juz_id_fkey FOREIGN KEY (juz_id) REFERENCES public.t_juz(id);


--
-- Name: t_target t_target_periode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_target
    ADD CONSTRAINT t_target_periode_id_fkey FOREIGN KEY (periode_id) REFERENCES public.a_periode(id);


--
-- Name: u_parents u_parents_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_parents
    ADD CONSTRAINT u_parents_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id);


--
-- Name: u_student_families u_student_families_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_student_families
    ADD CONSTRAINT u_student_families_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.u_students(user_id) ON DELETE CASCADE;


--
-- Name: u_students u_students_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_students
    ADD CONSTRAINT u_students_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.db_city(id);


--
-- Name: u_students u_students_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_students
    ADD CONSTRAINT u_students_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.db_district(id);


--
-- Name: u_students u_students_province_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_students
    ADD CONSTRAINT u_students_province_id_fkey FOREIGN KEY (province_id) REFERENCES public.db_province(id);


--
-- Name: u_students u_students_village_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.u_students
    ADD CONSTRAINT u_students_village_id_fkey FOREIGN KEY (village_id) REFERENCES public.db_village(id);


--
-- PostgreSQL database dump complete
--

